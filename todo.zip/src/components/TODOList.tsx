import React from 'react'
import { TODO } from '../model'
import SingleTodo from './SingleTodo';
import { Draggable, Droppable } from 'react-beautiful-dnd';

interface Props{
    todos:TODO[];
    setTodos:React.Dispatch<React.SetStateAction<TODO[]>>;
    setcompletedtodos:React.Dispatch<React.SetStateAction<TODO[]>>;
    completedtodos:TODO[]
}

const TODOList:React.FC<Props> = ({todos,setTodos,completedtodos,setcompletedtodos}) => {
  return (
            <div className='todolist_container'>

    <Droppable droppableId='TodoList'>
    {(provided)=>(
      <div 
      className='todo active'
      ref={provided.innerRef}
      {...provided.droppableProps}
      >
        <span>Active Tasks</span>
      {todos.map((todo,index)=>(<SingleTodo key={index} index={index} todos={todos} todo={todo} setTodos={setTodos} />))}
      {provided.placeholder}

      </div>

    )
    
    }
  
    </Droppable>
    
    <Droppable droppableId='TodoRemove'>
      {(provided)=>(
            <div 
            className='todo remove'
            ref={provided.innerRef}
            {...provided.droppableProps}
            >
            <span>Completed Tasks</span>
          {completedtodos.map((todo,index)=>(<SingleTodo key={index} index={index} todos={completedtodos} todo={todo} setTodos={setcompletedtodos} />))}
          {provided.placeholder}

          </div>
      )}
    </Droppable>

    </div>
  )
}

export default TODOList