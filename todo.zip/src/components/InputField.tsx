import React, { useRef, useState } from 'react'

interface Props {
todo:string;
setTodo:React.Dispatch<React.SetStateAction<string>>;
handleAdd:(e:React.FormEvent)=>void;
}

const InputField:React.FC<Props> = ({todo,setTodo,handleAdd}) => {
    const inputRefs=useRef<HTMLInputElement>(null) 
  return (
    <form className='inputs_container' onSubmit={(e)=>{
        handleAdd(e);
        inputRefs.current?.blur()
        }}>
    <input  type='text' ref={inputRefs} value={todo} onChange={(e)=>setTodo(e.target.value)} placeholder='Enter a task'/>
    <button className='submit'>GO</button>
  </form>

  )
}

export default InputField