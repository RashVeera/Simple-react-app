import React, { useEffect, useRef, useState } from 'react'
import { TODO } from '../model'
import { FaCheck } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import { FaRegEdit } from "react-icons/fa";
import { Draggable } from 'react-beautiful-dnd';



interface Props{
    todo:TODO;
    setTodos:React.Dispatch<React.SetStateAction<TODO[]>>;
    todos:TODO[];
    index:number;
}


const SingleTodo:React.FC<Props> = ({todo,setTodos,todos,index}) => {
    const [edit,setedit]=useState<boolean>(false);
    const [editTodo,seteditTodo]=useState<string>(todo.todo)
    const inputRef=useRef<HTMLInputElement>(null)
 
    const handledone =(id:number)=>{
        setTodos(todos.map((todo)=>(todo.id===id)?{...todo, isDone:!todo.isDone}:todo))
        }
    const handleDelete=(id:number)=>{
        setTodos(todos.filter((todo)=>todo.id!==id))
    }

    const handleSubmit=(e:React.FormEvent,id:number)=>{
        e.preventDefault()
        setTodos(todos.map((todo)=>todo.id===id?{...todo,todo:editTodo}:todo))
        setedit(false)
    }

    useEffect(()=>{
        inputRef.current?.focus()
    },[edit])
        
  return (
    <Draggable draggableId={todo.id.toString()} index={index} >
        {
            (provided)=>(
                <form 
                onSubmit={(e)=>{handleSubmit(e,todo.id)}} className='each__todo'
                ref={provided.innerRef}
                {...provided.draggableProps}
                {...provided.dragHandleProps}>
        {
            edit?(
                <input ref={inputRef} value={editTodo} onChange={(e)=>seteditTodo(e.target.value)} />
            ):(
                (todo.isDone)?(<s className='todo__name'>{todo.todo}</s>):
                <span className='todo__name'>{todo.todo}</span>
                
            )
        }
      
        <div>
            <span className='todo__edit' onClick={()=>
           {     if(!edit && !todo.isDone){
                    setedit(!edit)
            }}
            }><FaRegEdit/></span>
            <span className='todo__delete' onClick={()=>handleDelete(todo.id)}><MdDelete/></span>
            <span className='todo__done' onClick={()=>{handledone(todo.id)}}><FaCheck/></span>
        </div>
    </form>
            )
        }
    </Draggable>
  )
}

export default SingleTodo