import React, { useState } from 'react';
import './App.css';
import InputField from './components/InputField';
import { TODO } from './model';
import TODOList from './components/TODOList';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';

const App:React.FC=()=> {
  const [todo,setTodo]=useState<string>("");
  const [todos,setTodos]=useState<TODO[]>([])
  const [completedtodos,setcompletedtodos]=useState<TODO[]>([])
  console.log(todo)

  const handleAdd = (e:React.FormEvent) =>{
    e.preventDefault()
    if(todo){
      setTodos([...todos,{id:Date.now(),isDone:false,todo}])
      setTodo("")
    }
  }

  const dragend=(result:DropResult)=>{
    console.log(result)
    const {source,destination}=result;
    if(!destination) return;
    if((source.droppableId===destination.droppableId) && (source.index===destination.index) ) return;

    let add;
    let active=todos;
    let complete=completedtodos;

    if(source.droppableId==='TodoList'){
      add=active[source.index]
      active.splice(source.index,1)
    }
    else{
      add=complete[source.index]
      complete.splice(source.index,1)
    }

    if(destination.droppableId==="TodoList"){
      active.splice(destination.index,0,add)
    }
    else{
      complete.splice(destination.index,0,add)
    }

    setcompletedtodos(complete)
    setTodos(active)

    
  }

  return (
    <DragDropContext onDragEnd={dragend}>
    <div className="App">
      <h1 className='heading'>TASKIFY</h1>
      <InputField todo={todo} setTodo={setTodo} handleAdd={(e)=>{handleAdd(e)}}/>
      <TODOList todos={todos} setTodos={setTodos} setcompletedtodos={setcompletedtodos} completedtodos={completedtodos}/>
    </div>
    </DragDropContext>
  );
}

export default App;
