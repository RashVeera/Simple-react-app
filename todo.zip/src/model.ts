export interface TODO{
    id:number,
    isDone:boolean,
    todo:string
}