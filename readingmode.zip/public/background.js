chrome.runtime.onInstalled.addListener(()=>{
    debugger;
    console.log("background script is running")
})