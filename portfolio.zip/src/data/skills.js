import html from "../assets/html.png"
import css from "../assets/css.png"
import react from "../assets/react.png"
import node from "../assets/node.png"
import redux from "../assets/redux.png"

export const skills_dev=[
    {icon:html,
        title:"HTML"
    },
    {icon:css,
        title:"CSS"
    },
    {icon:react,
        title:"React"
    }, 
    {icon:node,
        title:"Node"
    }, 
    {icon:node,
        title:"Redux"
    },

]