import React from 'react'

const Header = () => {
  return (
    <div>
        <h3 className='header'>Expense Tracker</h3>
    </div>
  )
}

export default Header