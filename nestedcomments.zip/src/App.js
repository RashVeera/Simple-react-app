import './App.css';
import CommentsSection from './components/CommentSection';

function App() {
  return (
    <div className="App">
            <h1>Reddit-like Nested Comments</h1>
      <CommentsSection />

    </div>
  );
}

export default App;
