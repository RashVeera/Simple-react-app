import './App.css';
import LoginPhone from './components/LoginPhone';

function App() {
  return (
    <div className="App">
     <LoginPhone/>
    </div>
  );
}

export default App;
